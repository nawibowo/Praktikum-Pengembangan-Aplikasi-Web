<?php
	$angka  = rand(1,100);
	echo "Cetak angka: $angka";
?>